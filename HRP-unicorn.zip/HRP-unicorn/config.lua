Config                              = Config or {}

-- Framework
Config.Framework					= 'QBCore'		-- Choose which framework your server is using so kc-unicorn can work with it [ESX, QBCore, Standalone]
-- Since there is too many esx version, only this one is supported (https://github.com/esx-framework/es_extended/tree/v1-final). Maybe I will test other version, but not a priority

-- Lap dance 
Config.LapDanceCost					= 120 		-- Cost of the lap dance
Config.ThrowCost					= 100 		-- Cost per money throw
Config.LegMoney                     = 10000     -- Little easter egg for your player, will add an accessory "Leg money" to the stripper if the player has more than 'Config.LegMoney' in cash. Set to a huge value if you don't want this
Config.Nudity                       = true       -- Set to true if you want the stripper to be topless (Only for player above 'Config.NudityAge')
Config.NudityAge                    = 21        -- (QBCore only!!) Player age restriction. If underage and 'Config.Nudity' is set to true, the stripper won't be topless. Set to 0 if you don't want age restriction

-- Text/Blip/Marker
Config.Text 						= 'Better3D'   -- 2D, 3D, Better3D, None (Set the one you like to suit your server, the performance difference is mostly non-existant)
Config.Blip                         = true         -- Set to false if you don't want the blip on the map
Config.BlipName                     = "Strip-klubb" -- Blip name
Config.BlipStripclub = {
	Sprite = 121,  -- Sprite list can be found here: https://docs.fivem.net/docs/game-references/blips/
	Colour = 50,   -- Color list in the same URL as above
	Display = 27,   -- Explanation here: https://docs.fivem.net/natives/?_0x9029B2F3DA924928
	Scale = 0.7    -- Self explanatory, let you set the scale of the blip
}
Config.BlipCoord					= { x=117.9591, y=-1285.2666, z=29.2555 } -- If you want to move the blip on the map, change this.
Config.LapMarker					= true		-- Set to true if you want the marker for the lapdance to be "drawn"
Config.LapMarkerCoords              = vector3(114.3146, -1293.3623, 29.2555)
Config.LapDancePurchaseArea         = { x = 114.3146, y = -1293.3623, z = 29.2555, length = 1.24, width = 1.0, heading = 296.0789, minZ = 28.25, maxZ = 30.25 }

-- Seats
-- Configure where the player's custom seats are located and the strippers animations coordinates
Config.LapdanceSeats = {
    [1] = {
        playerCoords = vector3(120.5827, -1295.1000, 27.8177),
        playerHeading = 30.8591,
        pedCoords = vector3(119.4249, -1293.6285, 28.75),
        pedHeading = 207.1398,
        heading1 = 207.1398, heading2 = 207.1398, heading3 = 207.1398,
        vec1 = vector3(119.4249, -1293.6285, 28.75), vec2 = vector3(119.4249, -1293.6285, 28.75), vec3 = vector3(119.4249, -1293.6285, 28.75),
        duration = 5000
    },
    [2] = {
        playerCoords = vector3(116.2272, -1297.4873, 27.8177),
        playerHeading = 32.3476,
        pedCoords = vector3(115.3124, -1296.1144, 28.75),
        pedHeading = 210.6981,
        heading1 = 210.6981, heading2 = 210.6981, heading3 = 210.6981,
        vec1 = vector3(115.3124, -1296.1144, 28.75), vec2 = vector3(115.3124, -1296.1144, 28.75), vec3 = vector3(115.3124, -1296.1144, 28.75),
        duration = 5000
    },
    [3] = {
        playerCoords = vector3(112.0976, -1299.8058, 27.8177),
        playerHeading = 30.6240,
        pedCoords = vector3(111.2556, -1298.5587, 28.75),
        pedHeading = 210.3270,
        heading1 = 210.3270, heading2 = 210.3270, heading3 = 210.3270,
        vec1 = vector3(111.2556, -1298.5587, 28.75), vec2 = vector3(111.2556, -1298.5587, 28.75), vec3 = vector3(111.2556, -1298.5587, 28.75),
        duration = 5000
    },
    [4] = {
        playerCoords = vector3(107.7156, -1302.2664, 27.8177),
        playerHeading = 34.5625,
        pedCoords = vector3(107.0921, -1300.8657, 28.75),
        pedHeading = 208.0809,
        heading1 = 208.0809, heading2 = 208.0809, heading3 = 208.0809,
        vec1 = vector3(107.0921, -1300.8657, 28.75), vec2 = vector3(107.0921, -1300.8657, 28.75), vec3 = vector3(107.0921, -1300.8657, 28.75),
        duration = 5000
    }
}

-- Strippers
Config.SelectStrippers				= true		-- Set to true if you want to let your player choose which stripper they want for their lapdance
Config.Strippers = {
	[1] = {
		Name = "Eisha",
		Model = 1846523796,
		Drawables = { Head = 0, Hair = 0, Torso = 0, Torso2 = 0, Shoes = 1, Underwear = 0 },
		Textures = { HairTex = 0, BraTex = 2, ShoesTex = 2, UnderwearTex = 0 }
	},
	[2] = {
		Name = "Jade",
		Model = 1846523796,
		Drawables = { Head = 0, Hair = 2, Torso = 0, Torso2 = 0, Shoes = 1, Underwear = 0 },
		Textures = { HairTex = 0, BraTex = 1, ShoesTex = 1, UnderwearTex = 0 }
	},
    [3] = {
		Name = "Sophie",
		Model = 'a_f_m_fatcult_01',
		Drawables = { Head = 0, Hair = 2, Torso = 0, Torso2 = 0, Shoes = 1, Underwear = 0 },
		Textures = { HairTex = 0, BraTex = 1, ShoesTex = 1, UnderwearTex = 0 }
	}
}

-- Ambient Lapdance Strippers
Config.AmbientLapdancers = {
	{ model = 's_f_y_stripper_01', 	coords = vector4(106.6910, -1313.5939, 29.7486, 205.3082), animDict = "mini@strip_club@private_dance@part2", animName = "priv_dance_p2" },
	{ model = 'mp_f_stripperlite', 	coords = vector4(109.5183, -1311.7498, 29.7486, 205.6551), animDict = "mini@strip_club@private_dance@part1", animName = "priv_dance_p1" },
	{ model = 's_f_y_stripper_01', 	coords = vector4(112.3119, -1310.1240, 29.7486, 209.9332), animDict = "mini@strip_club@private_dance@part2", animName = "priv_dance_p2" },
	{ model = 'a_f_m_fatcult_01', 	coords = vector4(101.0951, -1293.6997, 29.2540, 295.9364), animDict = "mini@strip_club@private_dance@part1", animName = "priv_dance_p1" },
	{ model = 'mp_f_stripperlite', 	coords = vector4(99.2781, -1290.2659, 29.2540, 296.0504), animDict = "mini@strip_club@private_dance@part2", animName = "priv_dance_p2" },
	{ model = 's_f_y_stripper_01', 	coords = vector4(104.9576, -1289.5101, 28.8541, 297.1452), animDict = "mini@strip_club@private_dance@part1", animName = "priv_dance_p1" },
	{ model = 'mp_f_stripperlite', 	coords = vector4(109.5236, -1288.1257, 28.4542, 299.6653), animDict = "mini@strip_club@private_dance@part2", animName = "priv_dance_p2" },
	{ model = 's_f_y_stripper_01', 	coords = vector4(108.3610, -1286.0323, 28.4542, 301.2396), animDict = "mini@strip_club@private_dance@part1", animName = "priv_dance_p1" }
}

-- Bouncers
Config.Bouncers = {
	{ model = 's_m_y_valet_01', coords = vector4(131.1210, -1305.0948, 29.2096, 206.7932), animDict = "mini@strip_club@idles@bouncer@base", animName = "base" },
	{ model = 's_m_m_bouncer_01', coords = vector4(129.9225, -1298.2651, 29.2327, 207.1465), animDict = "mini@strip_club@idles@bouncer@base", animName = "base" },
	{ model = 's_m_m_bouncer_01', coords = vector4(127.8639, -1299.4823, 29.2327, 211.1884), animDict = "mini@strip_club@idles@bouncer@base", animName = "base" },
	{ model = 's_m_m_bouncer_01', coords = vector4(123.5698, -1294.4181, 29.2555, 298.0152), animDict = "mini@strip_club@idles@bouncer@base", animName = "base" },
	{ model = 's_m_m_bouncer_01', coords = vector4(126.9212, -1277.9277, 29.2555, 124.6051), animDict = "mini@strip_club@idles@bouncer@base", animName = "base" },
	{ model = 's_m_m_bouncer_01', coords = vector4(102.5094, -1300.4696, 29.2555, 299.3200), animDict = "mini@strip_club@idles@bouncer@base", animName = "base" },
	{ model = 's_m_m_bouncer_01', coords = vector4(99.6175, -1300.9679, 29.2555, 294.0064), animDict = "mini@strip_club@idles@bouncer@base", animName = "base" }
}

-- Locale
Config.Language						= 'en'		-- Currently Available: fr, en
-- Locales can be easily created or modified in `kc-unicorn/locales`

-- Misc
Config.Debug        				= false   	-- If you think something is not working, you can set 'Config.Debug' to true. It will then print a lot of debug information in your console
Config.DebugPolyzones				= false		-- Set to true if you want to display the Polyzones
Config.MoreDebug					= false		-- If set to true, this will print more debug about server and client lapdance seat status
Config.MoreDebugRefreshTime			= 5		-- Refresh time of "Config.MoreDebug" in seconds
Config.UpdateChecker                = true      -- Set to false if you don't want to check for resource update on start
Config.ChangeLog					= true		-- Set to false if you don't want to display the changelog if new version is find



----- DO NOT TOUCH! /!\ LOCALE SYSTEM /!\
Language = {}

function Loc(text,replacement)
    Language = (load)("return Locale." .. Config.Language)()

    if (load)("return Locale." .. Config.Language)() == nil then
        return 'Locale [' .. Config.Language .. '] (Does not exist/Is mispelled)'
    end
    if (load)("return ".."Language."..text)() == nil then
        return 'Error with [' .. Config.Language .. '.' .. text .. '] translation (Does not exist/Is mispelled)'
    end

	if replacement then
		text = (string.gsub((load)("return ".."Language."..text)(), "%%", replacement))
	else
		text = (load)("return ".."Language."..text)()
	end
	return text
end
-----------------------------------------