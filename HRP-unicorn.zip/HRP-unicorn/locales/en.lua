Locale                          = Locale or {}

Locale.en = { -- 'fr' är referensen som kommer att användas för 'Config.Language'
	StandaloneLapText			= "Be om en lap dance", -- Ställ in texten som visas ovanför markören om 'Config.Framework' är satt till 'standalone'
	LapText						= "Köp en lap dance (~g~%$~w~)", -- Ställ in texten som visas ovanför markören
	BoughtLapdance				= "Du köpte precis en lap dance för %$", -- Notifikationstext när en lap dance köps
	StripperActive				= "Stripparen är redan upptagen!", -- Notifikationstext om en stripper redan är aktiv när du försöker köpa en lap dance
	NotEnoughMoney				= "Du har inte tillräckligt med pengar. En lap dance kostar %$", -- Notifikationstext om spelaren inte har tillräckligt med pengar
	AllPlacesTaken				= "Alla platser är redan upptagna", -- Notifikationstext om alla platser redan är upptagna
	lapStopped					= "Din lap dance har avbrutits", -- Notifikationstext om lap dance avbryts
	Lean						= "Luta dig", -- Text som visas när man är nära pole dance
	StandaloneLeanNotice		= "Tryck ~INPUT_CONTEXT~ för att sluta luta dig\nTryck ~INPUT_JUMP~ för att kasta pengar", -- Text som visas när man lutar sig om 'Config.Framework' är satt till 'standalone'
	LeanNotice					= "Tryck ~INPUT_CONTEXT~ för att sluta luta dig\nTryck ~INPUT_JUMP~ för att kasta pengar (~g~%$~w~)", -- Text som visas när man lutar sig
	NotEnoughCashLean			= "Inte tillräckligt med pengar för att kasta" -- Text om spelaren inte har tillräckligt med pengar för att kasta medan man lutar sig
}